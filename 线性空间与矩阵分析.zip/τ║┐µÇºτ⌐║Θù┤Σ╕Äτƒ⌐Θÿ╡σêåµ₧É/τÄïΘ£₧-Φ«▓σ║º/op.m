f = @fun;

x0=[-1;-1;-1];
A = [];
b = [];
Aeq = [];
beq = [];
lb = [-1;-1;-1];
ub = [1;1;1];

[x,fval] = fmincon(f,x0,A,b,Aeq,beq,lb,ub)