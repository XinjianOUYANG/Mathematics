function [c,ceq] = con2b(x) 
c = [-x(1), 1-x(2),x(2)-10];
ceq = [];