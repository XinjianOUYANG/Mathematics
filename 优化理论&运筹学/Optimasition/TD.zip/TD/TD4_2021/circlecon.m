function [c,ceq] = circlecon(x) 
c = [1 - x(1) * x(2) , x(1) * x(2)-4];
ceq = [];
