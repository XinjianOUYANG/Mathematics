%% Initialisation
clear all;  
close all;  
clc

%% Part 1
J = @(x1,x2) x1.^2 + x2.^2 ;

fcontour(J,'--',[0 4]);
hold on;
tau = @(x1,x2) x1*x2;
fcontour(tau,'LevelList',[1]);
hold off;
grid on

%% Part 2a(p=1)
p = 1;
X1_a1 = [];
X2_a1 = [];
 for tau = 1:0.1:4
    fun = @(x) x(1).^2 + p * (tau./x(1)).^2 ;
    x0 = [0.5];
    A = [];
    b = [];
    Aeq = [];
    beq = [];
    lb = [0];
    ub = [ ];

    [x_a1,fval_a1] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub);
    X1_a1 = [X1_a1  x_a1];
    X2_a1 = [X2_a1 tau./x_a1];
 end

%% Part 2a(p=2)
p = 2;
X1_a2 = [];
X2_a2 = [];
 for tau = 1:0.1:4
    fun = @(x) x(1).^2 + p * (tau./x(1)).^2 ;
    x0 = [0.5];
    A = [];
    b = [];
    Aeq = [];
    beq = [];
    lb = [0];
    ub = [ ];

    [x_a2,fval_a2] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub);
    X1_a2 = [X1_a2  x_a2];
    X2_a2 = [X2_a2 tau./x_a2];
 end

%% part 2a: compare results
figure(1)

subplot(121)
tau = 1:0.1:4;
plot(tau,X1_a1,'*')
hold on;
plot(tau,X2_a1,'--')
hold off;
grid on;

subplot(122)
tau = 1:0.1:4;
plot(tau,X1_a2,'*')
hold on;
plot(tau,X2_a2,'--')
hold off;
grid on;

%% Part 2b(tau=1)
tau = 1;
X1_2b = [];
X2_2b = [];
J_opt_2b = []
for p = 1:0.1:10
    fun = @(x) x(1).^2 + p * tau./(x(1).^2) ;
    x0 = [0];
    A = [];
    b = [];
    Aeq = [];
    beq = [];
    lb = [0];
    ub = [];

    [x1_2b,fval_2b] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub);
    X1_2b = [X1_2b x1_2b];
    X2_2b = [X2_2b tau./x1_2b];
    J_opt_2b = [J_opt_2b fval_2b];
end
figure(2)
p = 1:0.1:10;
plot(p,X1_2b,'*');
hold on;
plot(p,X2_2b,'--');
hold on;
plot(p,J_opt_2b);
hold off;
grid on;

%% part 3a
tau = 1;
X1_3a = [];
X2_3a = [];
J_opt_3a = []
for p = 1:0.1:10
    fun = @(x) x(1).^2 + p * tau./(x(1).^2) ;
    x0 = [0];
    A = [];
    b = [];
    Aeq = [];
    beq = [];
    lb = [0];
    ub = [1.5];

    [x1_3a,fval_3a] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub);
    X1_3a = [X1_3a x1_3a];
    X2_3a = [X2_3a tau./x1_3a];
    J_opt_3a = [J_opt_3a fval_3a];
end

figure(3)
p = 1:0.1:10;
plot(p,X1_3a,'*');
hold on;
plot(p,X2_3a,'--');
hold on;
plot(p,J_opt_3a);
hold off;
grid on;

%% part 3a: compare 3b and 2b
figure(4)

subplot(121)
p = 1:0.1:10;
plot(p,X1_2b,'*')
hold on;
plot(p,X2_2b,'--')
hold on;
plot(p,J_opt_2b);
hold off;
grid on;

subplot(122)
p = 1:0.1:10;
plot(p,X1_3a,'*')
hold on;
plot(p,X2_3a,'--')
hold on;
plot(p,J_opt_3a)
hold off;
grid on;

%% part 3b
% J = x1.^2 + p * x2.^2 >= 2*sqrt(p)*x1*x2 = 2*sqrt(p)*tau
% when x1 = sqrt(p)x2, the equality holds.
% So J_min = 2*sqrt(p_max)*tau_max = 2 * sqrt(6) * 25  = 50 * sqrt(6)
% when tau = 25, p = 6;

% p=x(2), tau = 25

fun = @(x) x(1).^2 + x(2) * 25.^2./(x(1).^2) ;
x0 = [0 0];
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0 0];
ub = [ ];

% function [c,ceq] = con3b(x) 
% c = [-x(1), 4-x(2),x(2)-6]; % 0<=x(1), 4<=p=x(2)<=6
% ceq = [];
nonlcon = @con3b;

[x_3b,fval_3b] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,nonlcon)

% plot J* as a function of p
p = 4:pi/100:6;
J = x_3b(1).^2 + p * 25.^2./(x_3b(1).^2);
plot(p,J);
grid on;