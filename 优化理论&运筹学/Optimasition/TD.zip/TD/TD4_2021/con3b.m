function [c,ceq] = con3b(x) 
c = [-x(1), 4-x(2),x(2)-6];
ceq = [];