%% Initialisation
clear all;  
close all;  
clc

%% Task 1
%{
function my_val = objective_function(x)
    my_val = 3*((1-x(1)).^2) * exp(-x(1).^2-(x(2)+1).^2 
                - 10*(x(1)./5-x(1).^3-x(2).^5)*exp(-x(1).^2-x(2).^2) 
                - exp(-(x(1)+1).^2 - x(2).^2);
end
%}

%% Task 2
%{
if f_new <= hat_f
    % Here you shoud add your code for replacing hat_x by x_new
    hat_x = x_new;
    if f_new <= f_best
        % Here you should add your code for replacing x_best by x_new
        x_best = x_new;
        f_best = objective_function(x_best);
    end
% Here you should add your code for calculationg Delta_f and p
Delta_f = abs(f_new - hat_f);
p = exp(-Delta_f./T_current);
%}

%% Task 3
x_0 = [0.5,0.5];
lb = [-5,-5];
ub = [5,5];
T_0 = 100;
MAXITER = 1000;
F_best3 = [];
for i = 1:1:1000
    [f_best, x_best] = sim_ann(x_0, lb, ub, T_0, MAXITER);
    F_best3 = [F_best3 f_best];
end
Mean3 = mean(F_best3) 
Var3 = var(F_best3)
% Mean3 = -5.0439
% Var = 3.1889

%% Task 4
x_0 = [0.5,0.5];
lb = [-5,-5];
ub = [5,5];
T_0 = 100;
MAXITER = 50000;
N = [10 20 50 100];
Mean4 = [];
Var4 = [];

for n = N
    F_best = [];
    for i = 1:1:1000
        [f_best, x_best] = sim_ann4(x_0, lb, ub, T_0, n, MAXITER);
        F_best = [F_best f_best];
    end
    Mean4 = [Mean4 mean(F_best)]
    Var4 = [Var4 var(F_best)]
end
% Mean4 = [-6.5536   -6.5539   -6.5535   -6.5537]
% var4 = 1.0e-04 *[0.6621    0.7322    0.7400    0.7770]

%% Task 5
x_0 = [0.5,0.5];
lb = [-5,-5];
ub = [5,5];
MAXITER = 50000;
n = 50;
T = [10 20 50 100];
Mean5 = [];
Var5 = [];

for T_0 = T
    
    F_best = [];
    for i = 1:1:1000
        [f_best, x_best] = sim_ann4(x_0, lb, ub, T_0, n, MAXITER);
        F_best = [F_best f_best];
    end
    Mean5 = [Mean5 mean(F_best)]
    Var5 = [Var5 var(F_best)]
end
% Mean5 = [-6.5538   -6.5535   -6.5535   -6.5537]
% var5 =  1.0e-4 * [0.6652    0.6910    0.6923    0.7157]

%% Task 6
x_0 = [0.5,0.5];
lb = [-5,-5];
ub = [5,5];
n = 50;
T_0 = 10;
Mean6 = [];
Var6 = [];

for MAXITER = [5000,10000,50000,100000]
    F_best = [];
    for i = 1:1:1000
        [f_best, x_best] = sim_ann4(x_0, lb, ub, T_0, n, MAXITER);
        F_best = [F_best f_best];
    end
    Mean6 = [Mean6 mean(F_best)]
    Var6 = [Var6 var(F_best)]
end
% Mean6 = [-6.4280   -6.5132   -6.5534   -6.5578]
% var6 =  [0.0896    0.0059    0.0001    0.0000]

%% Task 7 
x_0 = [0.5,0.5];
lb = [-5,-5];
ub = [5,5];
T_0 = 100;
MAXITER = 1000;
F_best = [];
for alpha  = 0.1:1:50 
    [f_best, x_best] = sim_ann7(x_0, lb, ub, T_0, alpha, MAXITER);
    F_best = [F_best f_best];
end
F_best
% F_best = [-6.4807, -4.7984, -6.1408, ... -0.2241, -0.0318, -0.1869]
