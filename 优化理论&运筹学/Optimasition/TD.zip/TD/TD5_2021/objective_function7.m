function my_val = objective_function7(x, alpha)
    my_val = 3*((1-x(1)).^2) * exp(-x(1).^2-(x(2)+1).^2) - 10*(x(1)./5-x(1).^3-x(2).^5)*exp(-x(1).^2-x(2).^2) - exp(-(x(1)+1).^2 - x(2).^2);
    if sqrt(x(1).^2+x(2).^2) >= 3
        p = 0;
    else p = 1;
    end
    my_val = my_val + p * alpha; 
end


