function [f_best, x_best] = sim_ann_2(x_0, lb, ub, T_0, MAXITER,n)
%
% THIS IMPLEMENTATION UPDATES THE COOLING TEMPERATURE AT EACH STEP.
% The function implements a box constrained simulated annealing algorithm.
% The inputs to the function are the following:
%
%   + The starting point x_0
%   + A vector containing the lower bounds for each one the the variables
%   + A vector containing the upper bounds for each one of the varuables
%   + The initial temperature for simulated annealing
%   + The maximum number of trials
%
K = 0; % This is the iteration counter

%
% In the beginning, the current point from which the search starts is x_0.
% This is also the starting point for our minimizer
hat_x = x_0;
hat_f = objective_function(hat_x);

x_best = x_0;
f_best = hat_f;

% We initialie the temperature to be equal to T_0
T_current = T_0;

% Here I set the rule for substitutions:
num_of_accepted = 0;
for K = 1 : 1 : MAXITER    
    % Generate a feasible point in the neighborhood of hat_x 
    x_new = hat_x + (rand(size(x_0))-1/2);
    x_new = max(x_new, lb);
    x_new = min(x_new, ub);
      
    % Check the value of the objective point at x_new
    f_new = objective_function(x_new);
    
    % If the value at his point is better than the current, I update the
    % current point:
    
    if f_new <= hat_f
        % Here you shoud add your code for replacing hat_x by x_new
        hat_x = x_new;
        hat_f = f_new;
           
        if f_new <= f_best
            % Here you should add your code for replacing x_best by x_new
            x_best = x_new;
            f_best = f_new;
        end
        
        num_of_accepted = num_of_accepted + 1;
    
    else
        % Here you should add yoxur code for calculationg Delta_f and p
        Delta_f = abs(hat_f - f_new);
        p = exp(-Delta_f/T_current);
        
        % Generate a random number in the interval [0,1]
        my_rnd_num = rand();
        if p > my_rnd_num
            hat_x = x_new;
            hat_f = f_new;  
            num_of_accepted = num_of_accepted + 1;
        end
    end
    
    
    if num_of_accepted == n
        T_current = 0.9*T_current;
        num_of_accepted = 0;
    end
    
       
end

f_best;
x_best;


