function xp = projC2(x,P,Q,i,delta)

xp = projC1(x',Q,P,i,delta)';

end


