function [xp,E] = Dykstra(y,P,Q,delta,nitm,x)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

xp = y;
[K,L] = size(y);

m = 6;
d = zeros(m,K,L);

prec = 1e-7;

for nit = 1:nitm
    E(nit) = norm(x(:)-xp(:));
    for j = 1:m
        e = xp+squeeze(d(j,:,:));
        if j == 1
            xp = projC1(e,P,Q,0,delta);
        elseif j == 2
            xp = projC1(e,P,Q,1,delta);
        elseif j == 3
            xp = projC2(e,P,Q,0,delta);
        elseif j == 4
            xp = projC2(e,P,Q,1,delta);
        elseif j == 5
            xp = projC3(e,P,Q,0,delta);
        elseif j== 6
            xp = projC3(e,P,Q,1,delta);
        end
        d(j,:,:) = e-xp;
    end
    
    dC1 = max(max(abs(xp(P(1):P(2),Q(1):Q(2)-1)-xp(P(1):P(2),Q(1)+1:Q(2)))));
    dC2 = max(max(abs(xp(P(1):P(2)-1,Q(1):Q(2))-xp(P(1)+1:P(2),Q(1):Q(2)))));
    dC3 = max(max(abs(xp(P(1):P(2)-1,Q(1):Q(2)-1)-xp(P(1)+1:P(2),Q(1)+1:Q(2)))));
    if max([dC1 dC2 dC3]) <= delta+prec
        break;
    end
end

E(nit+1) = norm(x(:)-xp(:));

end

