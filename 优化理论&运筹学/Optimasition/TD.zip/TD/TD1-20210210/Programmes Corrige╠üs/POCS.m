function [xp,E] = POCS(y,P,Q,delta,nitm,x)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

xp = y;

m = 6;
prec = 1e-7;

for nit = 1:nitm
    E(nit) = norm(x(:)-xp(:));
    j = rem(nit-1,m)+1;
    if j == 1
        xp = projC1(xp,P,Q,0,delta);
    elseif j == 2
        xp = projC1(xp,P,Q,1,delta);
    elseif j == 3
        xp = projC2(xp,P,Q,0,delta);
    elseif j == 4
        xp = projC2(xp,P,Q,1,delta);
    elseif j == 5
        xp = projC3(xp,P,Q,0,delta);
    elseif j== 6
        xp = projC3(xp,P,Q,1,delta);
    end
    
    dC1 = max(max(xp(P(1):P(2),Q(1):Q(2)-1)-xp(P(1):P(2),Q(1)+1:Q(2))));
    dC2 = max(max(xp(P(1):P(2)-1,Q(1):Q(2))-xp(P(1)+1:P(2),Q(1):Q(2))));
    dC3 = max(max(xp(P(1):P(2)-1,Q(1):Q(2)-1)-xp(P(1)+1:P(2),Q(1)+1:Q(2))));
    if max([dC1 dC2 dC3]) <= delta+prec
        break;
    end
end

E(nit+1) = norm(x(:)-xp(:));


end

