%% Initialisation
clear all;  
close all;  
clc

D = [0.7094    0.1190    0.7513    0.5472;...
    0.7547    0.4984    0.2551    0.1386 ;...
    0.2760    0.9597    0.5060    0.1493;...
    0.6797    0.3404    0.6991    0.257 ;...
    0.6551    0.5853    0.8909    0.8407;...
    0.1626    0.2238    0.9593    0.2543];

c = [0.5383; 0.9961; 0.0782; 0.4427];

m = length(D);
n = length(c);

%% Question1: introductory task
N = 4;

A1=ones([N,N]);
b1 = 10 * ones([N,1]);

Aeq1 = zeros([N,N]);
beq1 = zeros([N,1]);

f1 = [10 11 20 39];
intcon=1:N;

lb1=zeros(N,1);
ub1=10*ones(N,1);

%x = intlinprog(f1,intcon,A1,b1,Aeq1,beq1,lb1,ub1)

%% Question2:
%﻿each client/citizen is served by EXACTLY ONE serving point
% 
% <<constaint1.png>>
% 


f=D'
F1=reshape(f,[1,24])
F=[F1 c'];
F = F';
%xi_j,count i first, then j
intcon=1:(m*n+n);

%﻿to ensure that we choose an avaliable service station for client.
p = zeros(m*n,n);
for i = 1:m*n
    j = ceil(i/m);
    p(i,j) = -1;
end
A = [eye(m*n),p];
b = zeros(m*n,1);

% to ensure﻿that one client/citizen can only be served by one service location. 
r=eye(m);
A2=repmat(r,1,n);
q = zeros(6,4);
Aeq=[A2,q];
beq = ones([m,1]);

%binary variables
lb=zeros(m*n+n,1);
ub=ones(m*n+n,1);

x = intlinprog(F,intcon,A,b,Aeq,beq,lb,ub)

%% Q3.1:new constrains
%﻿introduce the constraint that each client/citizen can beserved by AT LEAST one serving point.
f=D'
F1=reshape(f,[1,24])
F=[F1 c'];
F = F';
%xi_j,count i first, then j
intcon=1:(m*n+n);

%﻿to ensure that we choose an avaliable service station for client.
A1=[A;-Aeq];
b1=[b;-beq];

%binary variables
lb=zeros(m*n+n,1);
ub=ones(m*n+n,1);

x = intlinprog(F,intcon,A1,b1,[],[],lb,ub)

%% Q3.2:new constrains
%﻿introducing redundancy (i.e.ensuring that each client/consumer is served by at least two locations)
% while making sure that no client/citizen is not served by more than three locations.
A2=[A;-Aeq;Aeq];
b2=[b;-2.*beq;3.*beq];
x2=intlinprog(F,intcon,A2,b2,[],[],lb,ub);
