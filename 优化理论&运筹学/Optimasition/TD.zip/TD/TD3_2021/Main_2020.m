%% Initialisation
clear all;  
close all;  
clc
% load the data
T1=readtable('PositionsObjects.txt'); 
PositionsObjets=T1.x+1i*T1.y;  % positions defined by complex numbers
T2=readtable('PositionsBoxes.txt');   
PositionsBoxes=T2.x+1i*T2.y;
N = size(T1,1); % N = length (PositionsObjets);

%% Question2: formulate the oprimization problem as an ILP problem
q=ones([1,N]);
z=zeros([1,N]);
A1 = zeros(N,N*N);
for i = 1:N
    A1(i,N*i-(N-1):N*i) = q;
end

r=eye(N);
A2=repmat(r,1,N);
Aeq=[A1;A2];
beq=ones([2*N,1]);

F=[];
%a=height(T2)
for i = 1:height(T1)
    for j = 1: height(T2)
        %for every cell
        F(end+1)=sqrt((T1{i,1}-T2{j,1})^2+(T1{i,2}-T2{j,2})^2);
    end
end
f=F';
intcon=1:N*N;
%xi_j,count i first, then j
lb=zeros(N*N,1);
ub=ones(N*N,1);
%x = intlinprog(f,intcon,[],[],Aeq,beq,lb,ub);

%% Question3: new contraint
% object 1 must be in the box located just to the left of the box containing object 2
Q3=zeros([N,N*N]);
for i = 2:N
    Q3(i,N+i)=1;
    Q3(i,i-1)=-1;
end
Q3(1,N+1)=1;% ensure x_1_2 != 1
Aeq3=[Aeq;Q3];
beq3 = [beq; zeros([N,1])];
%x = intlinprog(f,intcon,[],[],Aeq3,beq3,lb,ub);

%% Question4: new constraint
% Object 3 cannot be put into the left of object 4
Q4=zeros([N-1,N*N]);
for i = 1:N-1
    Q4(i,2*N+i)=1;
    Q4(i,3*N+i+1:4*N)=1;
end
A4= Q4;
b4 = ones([N-1,1]);
%x = intlinprog(f,intcon,A4,b4,Aeq3,beq3,lb,ub);

%% Question5: new constraint
%﻿object 7 must be located next to the box containing object 9.
Q5=zeros([N,N*N]);
for i = 3:N-2 % o9 in box i
    Q5(i,6*N+i)=1;
    Q5(i,6*N+1:6*N+i-2)=1;
    Q5(i,6*N+2+i:105)=1;   
end
Q5(1,8*N+1)=1; % o9 in b1
Q5(1,6*N+3:7*N)=1;
Q5(2,8*N+2)=1; % o9 in b2
Q5(2,6*N+4:7*N)=1;
Q5(14,8*N+14)=1; % o 9 in b14
Q5(14,6*N+1:6*N+12)=1;
Q5(15,135)=1; % o9 in b15
Q5(15,6*N+1:6*N+13)=1;

A5=[A4; Q5];
b5 = ones([2*N-1,1]);
x = intlinprog(f,intcon,A5,b5,Aeq3,beq3,lb,ub);

%% optimization and structure the lines
Boxes = zeros(N,1);
for i=1:N
    for j =1:N
        if round(x((i-1)*N+j))==1
            Boxes(i) = j;
        end
    end
end

% Plot example with object i in the box i (1 in 1, 2 in 2, etc.)
PlotSolution (Boxes, PositionsObjets, PositionsBoxes)
